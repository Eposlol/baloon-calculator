(function () {
  'use strict';

  // ============================================================
  //  ЦЕНЫ — редактируйте здесь. Цена за 1 шар (руб) по тиражу.
  //  Столбцы: [1+0, 1+1, 2+0, 2+1, 2+2]
  //  (тиражи 2000+ по правилу «свыше 1000 — как за 1000»)
  // ============================================================
  var PRICES = {
    25: [60, 65, 75, 95, 105],
    50: [50, 55, 60, 80, 85],
    100: [29, 35, 50, 60, 70],
    200: [20, 25, 40, 45, 50],
    300: [18, 24, 40, 45, 50],
    400: [17, 22, 40, 45, 50],
    500: [14, 19, 30, 35, 40],
    1000: [12, 16, 23, 26, 31],
    2000: [12, 16, 23, 26, 31],
    3000: [12, 16, 23, 26, 31],
    5000: [12, 16, 23, 26, 31],
    10000: [12, 16, 23, 26, 31],
  };
  var METALLIC_PER_BALL = 1.5;   // надбавка за шар металлик (золото/серебро)
  var DIFF_SIDES_FEE = 1000;     // разные логотипы с 2-х сторон (доп. рамка)

  var TIERS = [25, 50, 100, 200, 300, 400, 500, 1000, 2000, 3000, 5000, 10000];

  var SHARS = [
    { n: 'Прозрачный', bg: 'linear-gradient(135deg,#fdfdfb,#e9e8df)', light: true, solid: '#d9d8cc' },
    { n: 'Белый', bg: '#ffffff', light: true },
    { n: 'Чёрный', bg: '#20201f' },
    { n: 'Синий', bg: '#1f52c4' },
    { n: 'Сиреневый', bg: '#9a86d6' },
    { n: 'Фиолетовый', bg: '#6a2fb5' },
    { n: 'Розовый', bg: '#f2a0c4' },
    { n: 'Фуксия', bg: '#d81b8c' },
    { n: 'Красный', bg: '#e01b22' },
    { n: 'Жёлтый', bg: '#f7d40a' },
    { n: 'Оранжевый', bg: '#f28a1a' },
    { n: 'Салатовый', bg: '#7ac70c' },
    { n: 'Зелёный', bg: '#1f9e3c' },
    { n: 'Бирюза', bg: '#16b3ad' },
    { n: 'Золото', bg: 'linear-gradient(135deg,#f6e27a,#c9a227 45%,#9a7b12 70%,#e8cf6b)', metallic: true, solid: '#c9a227' },
    { n: 'Серебро', bg: 'linear-gradient(135deg,#f4f5f7,#b8bcc0 45%,#8a8f95 70%,#e6e8ea)', metallic: true, solid: '#a9aeb3' },
  ];

  var PAINTS = [
    { n: 'Белый', bg: '#ffffff', light: true },
    { n: 'Розовый', bg: '#f2a0c4' },
    { n: 'Фуксия', bg: '#d81b8c' },
    { n: 'Золото', bg: 'linear-gradient(135deg,#f6e27a,#c9a227 55%,#9a7b12)', solid: '#c9a227' },
    { n: 'Красный', bg: '#e01b22' },
    { n: 'Коричневый', bg: '#7a4a12' },
    { n: 'Жёлтый', bg: '#f7d40a' },
    { n: 'Оранжевый', bg: '#f28a1a' },
    { n: 'Серебро', bg: 'linear-gradient(135deg,#f4f5f7,#b8bcc0 55%,#8a8f95)', solid: '#a9aeb3' },
    { n: 'Серый', bg: '#9aa0a6' },
    { n: 'Чёрный', bg: '#20201f' },
    { n: 'Зелёный', bg: '#1f9e3c' },
    { n: 'Голубой', bg: '#38b6ff' },
    { n: 'Сиреневый', bg: '#9a86d6' },
    { n: 'Фиолетовый', bg: '#6a2fb5' },
    { n: 'Синий', bg: '#1f52c4' },
  ];

  // варианты сторон/цветов 
  var OPTIONS = [
    { v: '1+0', label: '1+0 — 1 сторона, 1 цвет', a: 1, b: 0, col: 0, toggle: false },
    { v: '1+1', label: '1+1 — 2 стороны, 1 цвет', a: 1, b: 1, col: 1, toggle: true },
    { v: '2+0', label: '2+0 — 1 сторона, 2 цвета', a: 2, b: 0, col: 2, toggle: false },
    { v: '2+1', label: '2+1 — 2 стороны: 2 цвета и 1 цвет', a: 2, b: 1, col: 3, toggle: false },
    { v: '2+2', label: '2+2 — 2 стороны, по 2 цвета', a: 2, b: 2, col: 4, toggle: true },
  ];

  // ---------- Состояние ----------
  var state = {
    shar: 0,
    opt: '1+0',
    same: true,
    colorsA: [10],   // Чёрный
    colorsB: [10],
    qty: 50,
  };

  var submitting = false;

  // ---------- DOM ----------
  var $ = function (id) { return document.getElementById(id); };
  var el = {
    balloonBody: $('balloon-body'),
    balloonShadow: document.querySelector('.balloon__shadow'),
    logoFront: $('logo-front-el'),
    logoLeft: $('logo-left-el'),
    logoRight: $('logo-right-el'),
    sharName: $('shar-name'),
    sharSwatches: $('shar-swatches'),
    optSelect: $('opt-select'),
    sameToggle: $('same-toggle'),
    sameTrue: $('same-true'),
    sameFalse: $('same-false'),
    colorsA: $('colors-a'),
    colorsB: $('colors-b'),
    sideB: $('side-b'),
    qtySelect: $('qty-select'),
    totalValue: $('total-value'),
    totalPer: $('total-per'),
    orderBtn: $('order-btn'),
    formCard: $('order-form-card'),
    form: $('order-form'),
    thanks: $('thanks'),
    submitBtn: $('submit-btn'),
    formError: $('form-error'),
    honeypot: $('f-website'),
    summarySharDot: $('summary-shar-dot'),
    summarySharName: $('summary-shar-name'),
    summaryOpt: $('summary-opt'),
    summaryColors: $('summary-colors'),
    summaryQty: $('summary-qty'),
    summaryTotal: $('summary-total'),
  };


  // ---------- Яндекс SmartCaptcha (невидимая) ----------
  // Схема: клик «Отправить» → execute() → SDK показывает задание только
  // подозрительным пользователям → callback(token) → отправка на send.php.
  // Токен одноразовый и живёт ~5 минут, поэтому после каждой попытки reset().
  var captcha = { widgetId: null, token: null, ready: false, failed: false };

  window.onSmartCaptchaLoad = function () {
    var sitekey = el.form.getAttribute('data-captcha-key');
    if (!window.smartCaptcha || !sitekey || sitekey.indexOf('__') === 0) {
      captcha.failed = true;
      console.warn('SmartCaptcha: не указан клиентский ключ (data-captcha-key на форме)');
      return;
    }
    captcha.widgetId = window.smartCaptcha.render('captcha-container', {
      sitekey: sitekey,
      invisible: true,
      hideShield: false,          // по правилам Яндекса уведомление об обработке данных скрывать нельзя
      shieldPosition: 'bottom-right',
      callback: function (token) {
        captcha.token = token;
        doSubmit();
      },
    });
    // Пользователь закрыл окно с заданием — снимаем состояние «Отправка…»
    window.smartCaptcha.subscribe(captcha.widgetId, 'challenge-hidden', function () {
      if (submitting && !captcha.token) setSubmitting(false);
    });
    window.smartCaptcha.subscribe(captcha.widgetId, 'network-error', function () {
      if (submitting && !captcha.token) {
        showError('Не удалось связаться с сервисом проверки. Попробуйте ещё раз.');
        setSubmitting(false);
      }
    });
    captcha.ready = true;
  };

  function resetCaptcha() {
    captcha.token = null;
    if (captcha.ready && window.smartCaptcha) window.smartCaptcha.reset(captcha.widgetId);
  }

  // ---------- Отправка ----------
  async function submitOrder(orderData) {
    var res = await fetch('send.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData),
    });
    var json = null;
    try { json = await res.json(); } catch (e) { /* не-JSON ответ (например, 500 от хостинга) */ }
    if (!res.ok || !json || json.ok !== true) {
      throw new Error((json && json.error) || 'Сервер вернул ошибку ' + res.status);
    }
    return json;
  }

  function showError(text) {
    el.formError.textContent = text;
    el.formError.hidden = false;
  }
  function hideError() {
    el.formError.hidden = true;
    el.formError.textContent = '';
  }

  function setSubmitting(on) {
    submitting = on;
    el.submitBtn.disabled = on;
    el.submitBtn.textContent = on ? 'Отправка…' : 'Отправить';
  }

  // Клиентская валидация (у формы novalidate — ошибки показываем в своём блоке)
  function validateForm() {
    var fields = [$('f-name'), $('f-phone'), $('f-email'), $('f-msg')];
    fields.forEach(function (f) { f.classList.remove('order-form__input--invalid'); });

    var phone = $('f-phone').value.trim();
    var email = $('f-email').value.trim();
    var digits = phone.replace(/\D/g, '');
    if (digits.length < 6 || digits.length > 15) {
      $('f-phone').classList.add('order-form__input--invalid');
      return 'Укажите корректный телефон.';
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      $('f-email').classList.add('order-form__input--invalid');
      return 'Укажите корректный e-mail или оставьте поле пустым.';
    }
    return null;
  }


  async function doSubmit() {
    try {
      var data = buildOrderData();
      data.token = captcha.token;
      data.website = el.honeypot.value;   // honeypot: у людей пусто
      await submitOrder(data);
      el.form.hidden = true;
      el.thanks.hidden = false;
    } catch (err) {
      console.error('Не удалось отправить заказ:', err);
      showError(err.message || 'Не удалось отправить заявку. Попробуйте ещё раз.');
    } finally {
      resetCaptcha();
      setSubmitting(false);
    }
  }

  // ---------- Утилиты ----------
  function opt() { return OPTIONS.find(function (o) { return o.v === state.opt; }); }

  function resize(arr, n) {
    var out = [];
    for (var i = 0; i < n; i++) out.push(arr[i] != null ? arr[i] : 10);
    return out;
  }

  function fmt(n) { return Math.round(n).toLocaleString('ru-RU'); }

  function paintCss(i) { var p = PAINTS[i] || PAINTS[10]; return p.solid || p.bg; }


  function partColor(colors, part) {
    if ((part === 0 || part === 2) && colors.length > 1) return paintCss(colors[1]);
    return paintCss(colors[0]);
  }

  function calcPricing() {
    var o = opt();
    var tier = PRICES[state.qty] || PRICES[1000];
    var perBall = tier[o.col];
    var diffFee = (o.toggle && !state.same) ? DIFF_SIDES_FEE : 0;
    var metalFee = SHARS[state.shar].metallic ? METALLIC_PER_BALL * state.qty : 0;
    return { perBall: perBall, total: perBall * state.qty + diffFee + metalFee };
  }

  function showSideB() {
    var o = opt();
    return o.b > 0 && !(o.toggle && state.same);
  }

  // ---------- Логотипы (инлайн-symbol в index.html) ----------
  // Перекраска частей — через CSS-переменные на конкретном svg
  function paintLogo(svg, colors) {
    svg.style.setProperty('--logo-c0', partColor(colors, 0));
    svg.style.setProperty('--logo-c1', partColor(colors, 1));
    svg.style.setProperty('--logo-c2', partColor(colors, 2));
  }

  // ---------- Построение элементов ----------
  function buildSwatch(colorObj, selected) {
    var b = document.createElement('button');
    b.type = 'button';
    b.title = colorObj.n;
    b.className = 'swatch ' + 'swatch--sq'
      + (colorObj.light ? ' swatch--light' : '')
      + (selected ? ' swatch--selected' : '');
    b.style.background = colorObj.bg;  // data-driven: цвет из данных
    return b;
  }

  // ---------- Рендер: превью шара ----------
  function renderBalloon() {
    var shar = SHARS[state.shar];

    // CSS-переменные шара (data-driven)
    var base = (typeof shar.bg === 'string' && shar.bg[0] === '#')
      ? ('linear-gradient(' + shar.bg + ',' + shar.bg + ')') : shar.bg;
    var bg = 'radial-gradient(130% 120% at 32% 24%, rgba(255,255,255,' + (shar.light ? '.5' : '.28')
      + ') 0%, rgba(255,255,255,0) 42%, rgba(0,0,0,0) 62%, rgba(0,0,0,' + (shar.light ? '.10' : '.22')
      + ') 100%), ' + base;
    var shadow = shar.light
      ? 'drop-shadow(0 0 1px #c9c9bd) drop-shadow(0 3px 6px rgba(30,30,60,.22)) drop-shadow(0 18px 24px rgba(30,30,60,.28))'
      : 'drop-shadow(0 3px 6px rgba(30,30,60,.18)) drop-shadow(0 18px 24px rgba(30,30,60,.30))';

    // на контейнере, а не на теле: --balloon-bg наследуют и тело, и узелок
    el.balloonShadow.style.setProperty('--balloon-bg', bg);
    el.balloonShadow.style.setProperty('--balloon-shadow', shadow);
    el.balloonShadow.style.setProperty('--string-color', shar.solid || shar.bg);
    el.sharName.textContent = shar.n;

    // логотипы: 1 при односторонней печати, 2 при двухсторонней
    var o = opt();
    var twoSided = o.b > 0;
    var bColors = (o.toggle && state.same) ? state.colorsA : state.colorsB;
    // у svg нет свойства .hidden — переключаем атрибут (ловится CSS-правилом [hidden])
    el.logoFront.toggleAttribute('hidden', twoSided);
    el.logoLeft.toggleAttribute('hidden', !twoSided);
    el.logoRight.toggleAttribute('hidden', !twoSided);
    if (twoSided) {
      paintLogo(el.logoLeft, state.colorsA);
      paintLogo(el.logoRight, bColors);
    } else {
      paintLogo(el.logoFront, state.colorsA);
    }
  }

  // ---------- Рендер: свотчи шара ----------
  function renderSharSwatches() {
    el.sharSwatches.replaceChildren();
    SHARS.forEach(function (c, i) {
      var b = buildSwatch(c, state.shar === i);
      b.addEventListener('click', function () {
        state.shar = i;
        renderSharSwatches();
        renderBalloon();
        renderTotal();
      });
      el.sharSwatches.appendChild(b);
    });
  }

  // ---------- Рендер: ряды цветов логотипа ----------
  function renderColorRows(container, colorsKey, nColors) {
    container.replaceChildren();
    state[colorsKey].forEach(function (sel, slot) {
      var row = document.createElement('div');
      row.className = 'calc__color-row';

      var label = document.createElement('div');
      label.className = 'calc__color-row-label';
      label.textContent = nColors > 1 ? ('Цвет ' + (slot + 1)) : 'Цвет 1';
      row.appendChild(label);

      var grid = document.createElement('div');
      grid.className = 'calc__color-row-swatches';
      PAINTS.forEach(function (c, i) {
        var b = buildSwatch(c, sel === i, false);
        b.addEventListener('click', function () {
          state[colorsKey][slot] = i;
          renderColors();
          renderBalloon();
        });
        grid.appendChild(b);
      });
      row.appendChild(grid);
      container.appendChild(row);
    });
  }

  function renderColors() {
    var o = opt();
    renderColorRows(el.colorsA, 'colorsA', o.a);
    var sb = showSideB();
    el.sideB.hidden = !sb;
    if (sb) renderColorRows(el.colorsB, 'colorsB', o.b);
  }

  // ---------- Рендер: тумблер ----------
  function renderToggle() {
    var o = opt();
    el.sameToggle.hidden = !o.toggle;
    el.sameTrue.classList.toggle('calc__toggle-btn--active', state.same);
    el.sameFalse.classList.toggle('calc__toggle-btn--active', !state.same);
  }

  // ---------- Рендер: итог ----------
  function renderTotal() {
    var p = calcPricing();
    el.totalValue.textContent = fmt(p.total);
    el.totalPer.textContent = fmt(p.perBall) + ' руб./шт.';
  }

  function renderAll() {
    renderSharSwatches();
    renderToggle();
    renderColors();
    renderBalloon();
    renderTotal();
  }

  // ---------- Селекты (наполняются один раз) ----------
  function initSelects() {
    OPTIONS.forEach(function (x) {
      var op = document.createElement('option');
      op.value = x.v;
      op.textContent = x.label;
      el.optSelect.appendChild(op);
    });
    el.optSelect.value = state.opt;

    TIERS.forEach(function (t) {
      var op = document.createElement('option');
      op.value = t;
      op.textContent = t.toLocaleString('ru-RU');
      el.qtySelect.appendChild(op);
    });
    el.qtySelect.value = state.qty;
  }

  // ---------- Сводка заказа ----------
  function renderSummary() {
    var shar = SHARS[state.shar];
    var p = calcPricing();

    el.summarySharDot.style.background = shar.bg;
    el.summarySharName.textContent = shar.n;
    el.summaryOpt.textContent = state.opt;
    el.summaryQty.textContent = state.qty + ' шт.';
    el.summaryTotal.textContent = fmt(p.total) + ' руб.';

    var used = [];
    state.colorsA.forEach(function (i) { if (used.indexOf(i) === -1) used.push(i); });
    if (showSideB()) state.colorsB.forEach(function (i) { if (used.indexOf(i) === -1) used.push(i); });

    el.summaryColors.replaceChildren();
    used.forEach(function (i) {
      var dot = document.createElement('span');
      dot.className = 'order-form__dot';
      dot.style.background = PAINTS[i].bg;
      el.summaryColors.appendChild(dot);
    });
  }

  // ---------- Сбор данных заказа ----------
  function buildOrderData() {
    var o = opt();
    var p = calcPricing();
    return {
      shar: SHARS[state.shar].n,
      option: state.opt,
      sameBothSides: o.toggle ? state.same : null,
      qty: state.qty,
      colorsA: state.colorsA.map(function (i) { return PAINTS[i].n; }),
      colorsB: showSideB() ? state.colorsB.map(function (i) { return PAINTS[i].n; }) : null,
      pricePerBall: p.perBall,
      total: p.total,
      name: $('f-name').value,
      phone: $('f-phone').value,
      email: $('f-email').value,
      msg: $('f-msg').value,
    };
  }

  // Подписка на change, устойчивая к jQuery-плагинам.
  // Шаблон Bitrix (Aspro Next) прогоняет по странице ikSelect: он прячет
  // нативный <select> и на выбор пользователя делает value = ... + $(el).change().
  // jQuery.trigger не создаёт нативного DOM-события (метода el.change() в DOM нет),
  // поэтому addEventListener('change') на такой выбор не срабатывает.
  // Обработчик, повешенный через jQuery, ловит оба случая — и .trigger(), и обычный выбор.
  function onChange(node, handler) {
    if (window.jQuery) window.jQuery(node).on('change', handler);
    else node.addEventListener('change', handler);
  }

  // ---------- События ----------
  onChange(el.optSelect, function () {
    var o = OPTIONS.find(function (x) { return x.v === el.optSelect.value; });
    state.opt = o.v;
    state.colorsA = resize(state.colorsA, o.a);
    state.colorsB = resize(state.colorsB, o.b);
    renderToggle();
    renderColors();
    renderBalloon();
    renderTotal();
  });

  onChange(el.qtySelect, function () {
    state.qty = +el.qtySelect.value;
    renderTotal();
  });

  el.sameTrue.addEventListener('click', function () {
    state.same = true;
    renderToggle();
    renderColors();
    renderBalloon();
    renderTotal();
  });
  el.sameFalse.addEventListener('click', function () {
    state.same = false;
    renderToggle();
    renderColors();
    renderBalloon();
    renderTotal();
  });

  el.orderBtn.addEventListener('click', function () {
    renderSummary();
    el.formCard.hidden = false;
    el.form.hidden = false;
    el.thanks.hidden = true;
    el.formCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  // Первый этап: валидация → запуск невидимой капчи (её callback вызовет doSubmit)
  el.form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (submitting) return;
    hideError();

    var problem = validateForm();
    if (problem) { showError(problem); return; }

    if (!captcha.ready || !window.smartCaptcha) {
      showError(captcha.failed
        ? 'Проверка «я не робот» не настроена. Сообщите администратору сайта.'
        : 'Проверка «я не робот» ещё загружается. Подождите пару секунд и попробуйте снова.');
      return;
    }

    setSubmitting(true);
    captcha.token = null;
    window.smartCaptcha.execute(captcha.widgetId);
  });

  // ---------- Анимация ниточки ----------
  // Один GSAP-таймлайн ведёт и полёт шара, и морф ниточки — фазы сцеплены жёстко:
  // шар поднимается → завиток вытягивается почти в прямую (нить «натянута»),
  // шар опускается → нить расслабляется обратно в спираль.
  // Без CDN (нет gsap) остаётся CSS-анимация floaty со статичной ниточкой.
  function initStringSway() {
    if (!window.gsap || !window.MorphSVGPlugin) return;
    gsap.registerPlugin(MorphSVGPlugin);

    // лёгкая остаточная волна вместо идеальной прямой — так натуральнее
    var STRAIGHT_D = 'M20 0 C18 18 22 30 20 44 C18 58 22 70 20 84 C19 96 21 108 20 122 C20 130 20 140 20 148';

    var balloon = document.querySelector('.balloon');
    balloon.style.animation = 'none';           // floaty теперь ведёт GSAP
    gsap.set(balloon, { rotation: -0.6 });      // стартовая поза как в keyframes

    gsap.timeline({ repeat: -1, yoyo: true, defaults: { duration: 3, ease: 'sine.inOut' } })
      .to(balloon, { y: -10, rotation: 0.6 }, 0)
      .to('#string-path', { morphSVG: STRAIGHT_D }, 0);
  }

  // ---------- Старт ----------
  initSelects();
  renderAll();
  initStringSway();
})();
